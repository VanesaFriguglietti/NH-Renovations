-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 22, 2024 at 07:07 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `contacto`
--

-- --------------------------------------------------------

--
-- Table structure for table `datos`
--

CREATE TABLE `datos` (
  `id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `phone` int(20) NOT NULL,
  `message` varchar(300) NOT NULL,
  `dates` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `datos`
--

INSERT INTO `datos` (`id`, `name`, `email`, `address`, `phone`, `message`, `dates`) VALUES
(39, 'Vanesa Friguglietti', 'vanesafrigu@gmail.com', '16395 7 Th Concession', 2147483647, 'asdas', '02/21/24'),
(40, 'asd', 'aasda@asda.com', 'asdas', 2147483647, 'asddas', '02/21/24'),
(41, 'Vanesa Friguglietti', 'vanesafrigu@gmail.com', '16395 7 Th Concession', 2147483647, 'asdasasaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', '02/21/24'),
(42, 'van', 'asdasd@asdad.com', 'asdasdasd', 777777, 'asda', '02/21/24'),
(43, 'van', 'asdasd@asdad.com', 'asdasdasd', 777777, 'nnnnnnnnnnnnnnnn', '02/21/24'),
(44, 'van', 'asdasd@asdad.com', 'asdasdasd', 777778, 'hjgkjgh', '02/21/24'),
(45, 'nmm', 'asdasd@asdad.com', 'asdasdasd', 777778, 'hola', '02/21/24'),
(46, 'van', 'asdasd@asdad.com', 'asdasdasd', 7777884, 'aSsSasSSasS', '02/21/24'),
(47, 'Vanesa Friguglietti', 'vanesafrigu@gmail.com', '16395 7 Th Concession', 2147483647, 'asdasasaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', '02/21/24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `datos`
--
ALTER TABLE `datos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `datos`
--
ALTER TABLE `datos`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
