<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="icon" type="icon" href="imagen/NH.ico">
    <title>New Horizon</title>
  <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
      crossorigin="anonymous"
    />

    <!-- The website stylesheet -->
     <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <header>
   
       <div class="container ">
         <nav class="navbar navbar-expand-lg-end bg-body-tertiary narvar-light bg-light">
          <a class="navbar-brand" href="#">
            <img
            class="logo"
            src="imagen/NH.jpg"
            alt="BootstraPro Prp"
            width="170"
            height=" 60"
            />
          </a>

        <ul class="nav justify-content-end">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="services.html">Services</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="porfolio.html">Porfolio</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="form.php">Contact</a>
          </li>
        </ul>
      
      </nav>
      </div>
      <div class="container"> 
      <div
        class="cover d-flex justify-content-center align-items-center flex-column"style="background-image:url(imagen/contact.jpg);">
      
        <h1>Contact</h1>
        
        <a class="btn btn-primary" href="about.html" role="button">About Us</a>
      </div>
    </header>
    <div class="container"> 
      <div class="centro"> 
        
        
    	
        <form class="form" method="post"  autocomplete="off">
          <h2>Contact Us</h2>
          <div class="form-group">
            <div class="form-content">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" placeholder="Name" required="">
            </div>
            <div class="form-content">
              <label for="email">Email:</label>
              <input type="email" id="email" name="email" type="email" placeholder="ejemplo@email.com" required="">
            </div>
            <div class="form-content">
              <label for="address">Address:</label>
              <input type="text" id="address" name="address" placeholder="Address" required="">
            </div>
            <div class="form-content">
              <label for="subject">Subject:</label>
              <input type="text" id="subject" name="subject" placeholder="Full renovation" required="">
            </div>
          </div>
            
              <label for="message">Message:</label>
                <textarea id="message" name="message" placeholder="Message" cols="30" rows="10" required=""></textarea>
            
                <input class="btn-form" id="submit" name="contact" type="submit" onclick="hizoClick()" value="Submit">
                  <br/>
           
        </form>
      </div>
       </div>
        </div>
            <section>
     <div class="container mb-5 mt-5"> 
     <footer class="narvar-light bg-light">
        <div class="container mt-5 mb-5">
          <div class="row">
            <div class="col-lg-4">
              <h3>Enlaces</h3>
                <ul>
                  <li><a href="#">Inicio</a></li>
                  <li><a href="#">Acerca de</a></li>
                  <li><a href="#">Contacto</a></li>
                </ul>
            </div>
            <div class="col-lg-4">
              <h3>Contacto</h3>
              <p>Correo electrónico: info@example.com</p>
              <p>Teléfono: 416-970-8111</p>
            </div>
            <div class="col-lg-4">
              <h3>Derechos de autor</h3>
              <p>(c) 2024 Mi Sitio Web. Todos los derechos reservados.</p>
            </div>
          </div>
        </div>
      </footer>
   </div>
    </section> 
    </div>  
    <?php
    include("contacto.php")

      ?> 



    
</body>
</html>